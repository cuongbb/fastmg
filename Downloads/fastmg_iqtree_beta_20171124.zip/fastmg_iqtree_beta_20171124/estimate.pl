#!/usr/bin/perl
#Authors: Sau Nguyen Van, Cuong Dang
#Email: vansaucntt@gmail.com, cuongdc@vnu.edu.vn

use lib 'lib_dir';
use Parallel::ForkManager;
use Getopt::Std;
use strict;
use warnings;

sub usage(){
 print STDERR << "EOF";
usage: perl $0 -a alignmentFolder -s startingMatrixFile -o outputMatrixFile
EOF
  exit;
}

sub checkingState;  #Two parameters are aln_folder and iterration, iqtree_folder
sub runIqtree;		#Four parameters are aln_folder, current_iterration, matrix rate and output, iqtree_folder
sub runXrate;
################################### Main ##############################
#
#
#
#
#######################################################################
my %options=();
my $opt_string = 'a:i:s:t:o:h';
getopts("$opt_string",\%options) or usage();

if (!keys %options) { usage(); };
usage() if $options{h};

my $nThread = 1;
my $aln_folder 		= "Alignments";
my $iterration 		= 3;
my $input_matrix 	= "init_matrix.paml";
my $output_matrix 	= "output_matrix.paml";
my $iqtree_folder 	= "Iqtree_it";

$aln_folder 	= $options{a};
$iterration 	= $options{i};
$input_matrix 	= $options{s};
$output_matrix 	= $options{o};
$nThread		= $options{t};

######## Set default parameters #########
if($aln_folder eq ""){	$aln_folder = "Alignments";}
if($iqtree_folder eq ""){	$iqtree_folder = "Iqtree_it";}
if($iterration eq ""){	$iterration = 3;}
if($input_matrix eq ""){	$input_matrix = "lg_LG.PAML.txt";}
if($output_matrix eq ""){	$output_matrix = "output_matrix.paml";}
if($nThread eq ""){	$nThread = 1;}
#### end set default parameters #########

my $xrate_option = "-log 6 -rndtime -noa -mi 0.00001 -f 2";


for(my $i=1; $i <= $iterration; $i++){
	my $folder = $iqtree_folder.''.$i;
	unless(-d $folder){
		system("mkdir $folder");
	}
}

my $init = checkingState($aln_folder, $iterration, $iqtree_folder);

my $init_matrix = $input_matrix;
my $convertMatrix = "ConvertGrammar2Matrix.pl";
my $init_grammar = "init_grammar.eg";
my $train_grammar = "train_Grammar_it1";
my $current_iterration;
my $cmd;

open FILE, ">LogXrateTime.txt";

for(my $curr = $init; $curr<=$iterration; $curr++){
	$current_iterration = $curr;
	my $current_it = $curr;
	print "ITER ", $current_it, "\n";
	#Four parameters are aln_folder, current_iterration, matrix rate and output, iqtree_folder
	#remove file currupted before
	system("rm -f $aln_folder/*.bionj");
	system("rm -f $aln_folder/*.ckp.gz");
	system("rm -f $aln_folder/*.iqtree");
	system("rm -f $aln_folder/*.log");
	system("rm -f $aln_folder/*.mldist");
	system("rm -f $aln_folder/*.sitelh");
	system("rm -f $aln_folder/*.treefile");
	if ($curr>1){
		$init_matrix = $train_grammar."_PAML.txt";
		$init_grammar = $train_grammar;
		$train_grammar = "train_Grammar_it".$curr;
	}

#	runPhyML($aln_folder, $curr, $init_matrix, $output_matrix, $phyml_folder);
	runIqtree();
	
	my $start_run = time();
	runXrate($curr);
	my $end_run = time();
	my $run_time = $end_run - $start_run;
	printf FILE "$run_time\n";
}

$cmd = $cmd = "perl $convertMatrix -i train_Grammar_it".$iterration;
system($cmd);
$cmd = "mv train_Grammar_it".$iterration."_PAML.txt ".$output_matrix;
system($cmd);
close FILE;
exit;

#################################### End Main ######################################
#
#
#
#
#
################################### Subroutines ####################################
sub runXrate(){
	my ($current_iterration) = @_;
	$cmd = "perl Convert2Stockholm.pl -a $aln_folder -d Iqtree_it".$current_iterration;
	system($cmd);

	$cmd = "rm -r sub_*/*";
	system($cmd);
	
	$cmd = "./xrate $xrate_option -g $init_grammar -t $train_grammar Trainning.stk";
	system($cmd);

	$cmd = "perl $convertMatrix -i $train_grammar";
	system($cmd);

}

sub checkingState(){#input with options: a-alignmentFolder, i-interation, m-matrix, o-ouput
	my ($aln_folder, $iterration, $iqtree_folder) = @_;
	my $iterrate = 0;

	system("ls $aln_folder > listFileAlignments.txt");

	#checking steps itteration
	for(my $j=1; $j<$iterration; $j++){
		my $folder = $iqtree_folder.$j;
		open File, "<listFileAlignments.txt";
		while(my $aln = <File> ){
			$aln=~s/\n+$//;
			my $file_stats  = $aln.'.iqtree';
			my $file_tree   = $aln.'.treefile';
			my $file_lnl	= $aln.'.sitelh';
			if( (-e "$folder/$file_stats") and (-e "$folder/$file_tree") and (-e "$folder/$file_lnl") ){
				#exist file
			}else{
				$iterrate = $j;
				return $iterrate;
				last;
			}
		}#end while outer	
	}#end checking steps
	close File;
	#return $itteration;
}#end subroutine


sub runIqtree(){#input with options: a-alignmentFolder, i-interation, m-matrix, o-ouput
#	my ($aln_folder, $current_iterration, $matrix, $output, $iqtree_folder) = @_;
	my $matrix = $init_matrix;

	my $iterrate = 0;
	system("ls $aln_folder > listFileAlignments.txt");

	#checking steps itteration
	my $folder = $iqtree_folder.''.$current_iterration;
	my $manager = new Parallel::ForkManager($nThread);
	system("ls $aln_folder > listFileAlignments.txt");
	open File, "<listFileAlignments.txt";
	while(my $aln = <File> ){
		$manager->start and next;#$manager->start and next;
			$aln=~s/\n+$//;
			my $file_stats  = $aln.'.iqtree';
			my $file_tree   = $aln.'.treefile';
			my $file_lnl	= $aln.'.sitelh';
			if( (-e "$folder/$file_stats") && (-e "$folder/$file_tree") && (-e "$folder/$file_lnl") ){
				#exist file
			}else{
				my $cmd;
#				$cmd = "./phyml -i $aln_folder/$aln -d aa --quiet -q -c 4 -a e -v 0 -b 0 -s SPR -o lr -m custom --aa_rate_file $matrix --print_site_lnl";
				$cmd = "./iqtree -s $aln_folder/$aln -quiet -st AA -redo -quiet -wslg -m $matrix+G4";
				system($cmd );	
				system("mv $aln_folder/$aln.* $folder");	
			}
		$manager->finish;
	};#end while outer	
	$manager->wait_all_children;
	close File;
	#return $itteration;
}#end subroutine

