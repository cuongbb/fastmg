#!/usr/bin/perl -w
#use Getopt::Long;  # to parse command line parameters
use Getopt::Std;  # to parse command line parameters
use strict;
use warnings;
use lib 'lib_dir';
use Cwd;
use Bio::Phylo::IO;
use Phylip;

sub usage(){
  print STDERR << "EOF";
usage: perl $0 -a alignsFolder -d phymlFolder -e execFolder
EOF
  exit;
}

my %options=();
my $opt_string = 'a:d:h';
getopts("$opt_string",\%options) or usage();

if (!keys %options) { usage(); };
usage() if $options{h};

my $aln_folder = $options{a};
my $phyml_folder = $options{d};

my $sub_aln_folder = "sub_aln";
my $sub_tree_folder = "sub_tree";

my $aln_line;
my $lk_line;
my $tree_line;
my $i;
my @files = (  ); 
my $aln_file;
my $lk_file;
my $stats_file;
my $tree_file;
my $sub_aln_cat1_file;
my $sub_aln_cat2_file;
my $sub_aln_cat3_file;
my $sub_aln_cat4_file;
my $sub_tree_cat1_file;
my $sub_tree_cat2_file;
my $sub_tree_cat3_file;
my $sub_tree_cat4_file;
my $aln_input_file;
my $tree_input_file;
my $lk_input_file;
my $count_aln;
my $count_site;
my @split_values;
my $cat1;
my $cat2;
my $cat3;
my $cat4;
my $cat_rate_1;
my $cat_rate_2;
my $cat_rate_3;
my $cat_rate_4;

my $align_id = 0;
my $stock_id = 0;
my $count_tree = 0;
my @random_id;
my @random_id_count;
my @fileList;

unless(opendir(FOLDER, $aln_folder)) { 		print "Cannot open folder $aln_folder!\n"; 		exit; 	}
@files = readdir(FOLDER); 
closedir(FOLDER);

foreach my $t (@files) {
	if (($t ne ".") and ($t ne "..")) {
		push(@fileList, $t);
	}
}

my $number_of_aligns = @fileList;
#print"number_of_aligns: $number_of_aligns\n";

#my $output_stk_file = "Sample.stk";
my $output_stk_file = "Trainning.stk";

open ( my $outFile, '>', $output_stk_file )	   or die "Cannot open the output file: $output_stk_file: $!";
printf $outFile "# STOCKHOLM 1.0\n";

for ($i = 0; $i < $number_of_aligns; $i++) {
	$aln_file = "$aln_folder/$fileList[$i]";
	$lk_file = $phyml_folder . "/" . $fileList[$i] . ".sitelh";
	$tree_file = $phyml_folder . "/" . $fileList[$i] . ".treefile";
	
#	print "Process file $i $aln_file\n";
	my $stock = Phylip->from_file ($aln_file);
	my $cols = $stock->sequences();
#	print "cols: $cols\n";
	my $rowIndex = 0;
	my $rowName = $stock->seqname->[$rowIndex];
#	print "rowName: $rowName\n";
	my $row = $stock->seqdata->{$rowName};
#	print "row: $row\n";

	$count_aln = $rowName;
	$count_site	= $row;
#	exit;
	
#	open ( my $aln_input_file, '<', $aln_file )			   or die "Cannot open the input file: $aln_file: $!";
	open ( my $lk_input_file, '<', $lk_file )			   or die "Cannot open the input file: $lk_file: $!";

	# Process first line of aln file to get no of alns & site length
#	$aln_line = <$aln_input_file>;
#	@split_values = split(' ', $aln_line);
#	($count_aln, $count_site) = @split_values;
	
	#by pass next lines of aln file
#	$aln_line = <$aln_input_file>;
	
	#by pass 5 first lines of lk file
	for (my $temp = 0; $temp < 5; $temp++) {$lk_line = <$lk_input_file>;}

	#Process line 6 to get 4 cat rates
	$lk_line = <$lk_input_file>;
	@split_values = split(/[=\)]/, $lk_line);
	$cat_rate_1 = $split_values[3];
	$cat_rate_2 = $split_values[6];
	$cat_rate_3 = $split_values[9];
	$cat_rate_4 = $split_values[12];

	my @site_array;
	my $count_site_cat1 = 0;
	my $count_site_cat2 = 0;
	my $count_site_cat3 = 0;
	my $count_site_cat4 = 0;

	#From line 7, Process each site to get cat which have max likelihood
	for (my $j = 0; $j < $count_site; $j++)	{
		$lk_line = <$lk_input_file>;
		@split_values = split(' ', $lk_line);
		(my $temp, my $temp2, $cat1, $cat2, $cat3, $cat4) = @split_values;
		if(($cat1 >= $cat2) && ($cat1 >= $cat3) && ($cat1 >= $cat4)) {	push(@site_array, 1);			next;}
		if(($cat2 >= $cat1) && ($cat2 >= $cat3) && ($cat2 >= $cat4)) {	push(@site_array, 2);			next;}
		if(($cat3 >= $cat1) && ($cat3 >= $cat2) && ($cat3 >= $cat4)) {	push(@site_array, 3);			next;}
		if(($cat4 >= $cat1) && ($cat4 >= $cat2) && ($cat4 >= $cat3)) {	push(@site_array, 4);			next;}

	}
#	print "@site_array \n";
	close ($lk_input_file);

	foreach my $site(@site_array) {
		if ($site == 1) {$count_site_cat1++;}
		if ($site == 2) {$count_site_cat2++;}
		if ($site == 3) {$count_site_cat3++;}
		if ($site == 4) {$count_site_cat4++;}
	}

#	my @alnList;
#	for (my $j = 0; $j < $count_aln; $j++)	{
#		$aln_line = <$aln_input_file>;
#		push(@alnList, $aln_line);
#	}	

	my @alnList;
	for (my $j = 1; $j <= $count_aln; $j++)	{
		$rowIndex = $j;
		$rowName = $stock->seqname->[$rowIndex];
#		print "rowName: $rowName\n";
		$row = $stock->seqdata->{$rowName};
#		print "row: $row\n";
		$aln_line = $rowName.' '. $row;
		push(@alnList, $aln_line);
	}	

	###################################################################################################

#		print"random_id_count: $random_id_count[$align_id]\n";
	$sub_aln_cat1_file = $sub_aln_folder . "/" . $fileList[$i] . "_cat1_$stock_id";
	$sub_aln_cat2_file = $sub_aln_folder . "/" . $fileList[$i] . "_cat2_$stock_id";
	$sub_aln_cat3_file = $sub_aln_folder . "/" . $fileList[$i] . "_cat3_$stock_id";
	$sub_aln_cat4_file = $sub_aln_folder . "/" . $fileList[$i] . "_cat4_$stock_id";
	
	open ( my $outSubAlnCat1, '>', $sub_aln_cat1_file )		   or die "Cannot open the output file: $sub_aln_cat1_file: $!";
	open ( my $outSubAlnCat2, '>', $sub_aln_cat2_file )		   or die "Cannot open the output file: $sub_aln_cat2_file: $!";
	open ( my $outSubAlnCat3, '>', $sub_aln_cat3_file )		   or die "Cannot open the output file: $sub_aln_cat3_file: $!";
	open ( my $outSubAlnCat4, '>', $sub_aln_cat4_file )		   or die "Cannot open the output file: $sub_aln_cat4_file: $!";

	printf $outSubAlnCat1 "$count_aln $count_site_cat1\n";
	printf $outSubAlnCat2 "$count_aln $count_site_cat2\n";
	printf $outSubAlnCat3 "$count_aln $count_site_cat3\n";
	printf $outSubAlnCat4 "$count_aln $count_site_cat4\n";

	for (my $j = 0; $j < $count_aln; $j++)	{
		$aln_line = $alnList[$j];
		@split_values = split(' ', $aln_line);
		(my $id, my $sequence) = @split_values;
		my @string_split = split(//,$sequence);

		printf $outSubAlnCat1 $id . "_cat1_$stock_id\t";
		printf $outSubAlnCat2 $id . "_cat2_$stock_id\t";
		printf $outSubAlnCat3 $id . "_cat3_$stock_id\t";
		printf $outSubAlnCat4 $id . "_cat4_$stock_id\t";
		
		for (my $k = 0; $k < $count_site; $k++) {
			if($site_array[$k] == 1) {printf $outSubAlnCat1 "$string_split[$k]";}
			if($site_array[$k] == 2) {printf $outSubAlnCat2 "$string_split[$k]";}
			if($site_array[$k] == 3) {printf $outSubAlnCat3 "$string_split[$k]";}
			if($site_array[$k] == 4) {printf $outSubAlnCat4 "$string_split[$k]";}
		}
		printf $outSubAlnCat1 "\n";
		printf $outSubAlnCat2 "\n";
		printf $outSubAlnCat3 "\n";
		printf $outSubAlnCat4 "\n";

	}
	close ($outSubAlnCat1);
	close ($outSubAlnCat2);
	close ($outSubAlnCat3);
	close ($outSubAlnCat4);

	$sub_tree_cat1_file = $sub_tree_folder . "/" . $fileList[$i] . "_tree1_$stock_id";
	$sub_tree_cat2_file = $sub_tree_folder . "/" . $fileList[$i] . "_tree2_$stock_id";
	$sub_tree_cat3_file = $sub_tree_folder . "/" . $fileList[$i] . "_tree3_$stock_id";
	$sub_tree_cat4_file = $sub_tree_folder . "/" . $fileList[$i] . "_tree4_$stock_id";

	open ( my $outSubTreeCat1, '>', $sub_tree_cat1_file )		   or die "Cannot open the output file: $sub_tree_cat1_file: $!";
	open ( my $outSubTreeCat2, '>', $sub_tree_cat2_file )		   or die "Cannot open the output file: $sub_tree_cat2_file: $!";
	open ( my $outSubTreeCat3, '>', $sub_tree_cat3_file )		   or die "Cannot open the output file: $sub_tree_cat3_file: $!";
	open ( my $outSubTreeCat4, '>', $sub_tree_cat4_file )		   or die "Cannot open the output file: $sub_tree_cat4_file: $!";

	my $forest;
	my $tree;

	$forest = Bio::Phylo::IO->parse( -format => 'newick', -file    => $tree_file );
	$tree = $forest->first;
	foreach my $node ( @{ $tree->get_entities } ) {
		if (!$node->is_root() && defined($node->get_name)) {
			$node->set_name($node->get_name . "_cat1_$stock_id");		
			my $new_length = $node->get_branch_length() * $cat_rate_1;
			$node->set_branch_length($new_length);
		}
	}
	printf $outSubTreeCat1 $tree->to_newick() . "\n";

	$forest = Bio::Phylo::IO->parse( -format => 'newick', -file    => $tree_file );
	$tree = $forest->first;
	foreach my $node ( @{ $tree->get_entities } ) {
		if (!$node->is_root() && defined($node->get_name)) {
			$node->set_name($node->get_name . "_cat2_$stock_id");		
			my $new_length = $node->get_branch_length() * $cat_rate_2;
			$node->set_branch_length($new_length);
		}
	}
	printf $outSubTreeCat2 $tree->to_newick() . "\n";

	$forest = Bio::Phylo::IO->parse( -format => 'newick', -file    => $tree_file );
	$tree = $forest->first;
	foreach my $node ( @{ $tree->get_entities } ) {
		if (!$node->is_root() && defined($node->get_name)) {
			$node->set_name($node->get_name . "_cat3_$stock_id");		
			my $new_length = $node->get_branch_length() * $cat_rate_3;
			$node->set_branch_length($new_length);
		}
	}
	printf $outSubTreeCat3 $tree->to_newick() . "\n";

	$forest = Bio::Phylo::IO->parse( -format => 'newick', -file    => $tree_file );
	$tree = $forest->first;
	foreach my $node ( @{ $tree->get_entities } ) {
		if (!$node->is_root() && defined($node->get_name)) {
			$node->set_name($node->get_name . "_cat4_$stock_id");		
			my $new_length = $node->get_branch_length() * $cat_rate_4;
			$node->set_branch_length($new_length);
		}
	}
	printf $outSubTreeCat4 $tree->to_newick() . "\n";

	close ($outSubTreeCat1);
	close ($outSubTreeCat2);
	close ($outSubTreeCat3);
	close ($outSubTreeCat4);

	
	###################################################################################################
	open ( my $inSubAlnCat1, '<', $sub_aln_cat1_file )		   or die "Cannot open the input file: $sub_aln_cat1_file: $!";
	open ( my $inSubAlnCat2, '<', $sub_aln_cat2_file )		   or die "Cannot open the input file: $sub_aln_cat2_file: $!";
	open ( my $inSubAlnCat3, '<', $sub_aln_cat3_file )		   or die "Cannot open the input file: $sub_aln_cat3_file: $!";
	open ( my $inSubAlnCat4, '<', $sub_aln_cat4_file )		   or die "Cannot open the input file: $sub_aln_cat4_file: $!";

	open ( my $inSubTreeCat1, '<', $sub_tree_cat1_file )		   or die "Cannot open the input file: $sub_tree_cat1_file: $!";
	open ( my $inSubTreeCat2, '<', $sub_tree_cat2_file )		   or die "Cannot open the input file: $sub_tree_cat2_file: $!";
	open ( my $inSubTreeCat3, '<', $sub_tree_cat3_file )		   or die "Cannot open the input file: $sub_tree_cat3_file: $!";
	open ( my $inSubTreeCat4, '<', $sub_tree_cat4_file )		   or die "Cannot open the input file: $sub_tree_cat4_file: $!";

	my $sub_aln_line;
	my $sub_tree_line;
	my $count_sub_aln;
	my $count_sub_site;
	$sub_aln_line = <$inSubAlnCat1>;
	@split_values = split(' ', $sub_aln_line);
	($count_sub_aln, $count_sub_site) = @split_values;
	if ($count_sub_site > 0) {
		while ($sub_aln_line = <$inSubAlnCat1>) { printf $outFile "$sub_aln_line"; }		
		close ($inSubAlnCat1);
		printf $outFile "#=GF TN\t\t$count_tree\n";
		$count_tree++;
		printf $outFile "#=GF NH\t\t";
		while ($sub_tree_line = <$inSubTreeCat1>) { printf $outFile "$sub_tree_line"; }		
		close ($inSubTreeCat1);
		printf $outFile "\n//\n\n";
	}

	$sub_aln_line = <$inSubAlnCat2>;
	@split_values = split(' ', $sub_aln_line);
	($count_sub_aln, $count_sub_site) = @split_values;
	if ($count_sub_site > 0) {
		while ($sub_aln_line = <$inSubAlnCat2>) { printf $outFile "$sub_aln_line"; }		
		close ($inSubAlnCat2);
		printf $outFile "#=GF TN\t\t$count_tree\n";
		$count_tree++;
		printf $outFile "#=GF NH\t\t";
		while ($sub_tree_line = <$inSubTreeCat2>) { printf $outFile "$sub_tree_line"; }		
		close ($inSubTreeCat2);
		printf $outFile "\n//\n\n";
	}

	$sub_aln_line = <$inSubAlnCat3>;
	@split_values = split(' ', $sub_aln_line);
	($count_sub_aln, $count_sub_site) = @split_values;
	if ($count_sub_site > 0) {
		while ($sub_aln_line = <$inSubAlnCat3>) { printf $outFile "$sub_aln_line"; }		
		close ($inSubAlnCat3);
		printf $outFile "#=GF TN\t\t$count_tree\n";
		$count_tree++;
		printf $outFile "#=GF NH\t\t";
		while ($sub_tree_line = <$inSubTreeCat3>) { printf $outFile "$sub_tree_line"; }		
		close ($inSubTreeCat3);
		printf $outFile "\n//\n\n";
	}

	$sub_aln_line = <$inSubAlnCat4>;
	@split_values = split(' ', $sub_aln_line);
	($count_sub_aln, $count_sub_site) = @split_values;
	if ($count_sub_site > 0) {
		while ($sub_aln_line = <$inSubAlnCat4>) { printf $outFile "$sub_aln_line"; }		
		close ($inSubAlnCat4);
		printf $outFile "#=GF TN\t\t$count_tree\n";
		$count_tree++;
		printf $outFile "#=GF NH\t\t";
		while ($sub_tree_line = <$inSubTreeCat4>) { printf $outFile "$sub_tree_line"; }		
		close ($inSubTreeCat4);
		printf $outFile "\n//\n\n";
	}
	$stock_id++;

#	close ($aln_input_file);
	$align_id++;
}
close ($outFile);
