#!/usr/bin/perl -w
#use Getopt::Long;  # to parse command line parameters
use Getopt::Std;  # to parse command line parameters
use strict;
use warnings;
use feature qw/switch/; 
my $MINVALUE = 0.0000000001;
sub usage()
{
  print STDERR << "EOF";

usage: perl $0 -i input
EOF

  exit;
}

my %options=();
my $opt_string = 'i:h';
getopts("$opt_string",\%options) or usage();

if (!keys %options) { usage(); };
usage() if $options{h};

my $origFile = $options{i};


#my $usage = "Usage: perl ConvertMatrix.pl input\n";
#my $origFile = shift or die($usage);
my $outputFile = "$origFile"."_PAML.txt";

open ( my $inFile, '<', $origFile )		   or die "Cannot open the input file: $origFile: $!";
open ( my $outFile, '>', $outputFile )		   or die "Cannot open the output file: $outputFile: $!";

my @R;
my @Q;
my @pi;
my @temp;
my $line;

while ($line = <$inFile>) {

	if ($line =~ m/;; initial probability distribution/) {
		for (my $i=0; $i<20; $i++) {
			$line = <$inFile>;
			chomp($line);
			my @values = split(/\)/, $line);
			my $t = $values[2];
			@values = split(/ /, $t);
			$t = $values[2];
			$pi[$i] = $t;
		}
	}

	for (my $i=0; $i<20; $i++) {
		for (my $j=0; $j<20; $j++) {
			$Q[$i][$j] = $MINVALUE;
		}
	}

	if ($line =~ m/;; mutation rates/) {
		do {
			$line = <$inFile>;
			chomp($line);
			if ($line =~ m/;; end chain/) { last; }
			my @values = split(/\)/, $line);
			my $rate = $values[4];
			my $aa1 = $values[0];
			my $aa2 = $values[2];
			$aa1 = substr($aa1, length($aa1)-1, 1);
			$aa2 = substr($aa2, length($aa2)-1, 1);
			my $aa1_i = AA2Int($aa1);
			my $aa2_i = AA2Int($aa2);
			@values = split(/ /, $rate);
			$rate = $values[2];
			if ($rate < $MINVALUE) {
				$rate = $MINVALUE;
			}
			$Q[$aa1_i][$aa2_i] = $rate;
#			print "$rate\n";
		} while (1);
	}
}

for (my $i=0; $i<20; $i++) {
	for (my $j=0; $j<20; $j++) {
		if ($i > $j) {
			$R[$i][$j] = $Q[$i][$j] / $pi[$j];
		}
	}
}

my $temp=0;
for(my $x=0;$x<20;$x++) {
	$temp = 0;
	for(my $y=0;$y<20;$y++) {
		if($x!=$y) {
			$temp += $Q[$x][$y];
		}
	}
	$Q[$x][$x] = -$temp;
}

my $miu=0;
for(my $x=0;$x<20;$x++) {
	$miu = $miu - $pi[$x]*$Q[$x][$x];
}
#print "$miu\n";

for(my $x=0;$x<20;$x++) {
	for(my $y=0;$y<20;$y++) {
		if($y<$x) {
			$R[$y][$x]=$R[$x][$y]/$miu;
		}
	}
}

for (my $i=0; $i<20; $i++) {
	for (my $j=0; $j<20; $j++) {
		if ($i > $j) {
			printf $outFile "\%.9f ",$R[$i][$j];
		}
	}
	print $outFile "\n";
}

print $outFile "\n";

for (my $j=0; $j<20; $j++) {
	printf $outFile "\%.9f ",$pi[$j];

}

close ($outFile);
close ($inFile);

sub AA2Int{
	my ($aa) = @_;	given($aa) {
	    when ('a') { return 0; }
		when ('r') { return 1; }
		when ('n') { return 2; }
		when ('d') { return 3; }
		when ('c') { return 4; }
		when ('q') { return 5; }
		when ('e') { return 6; }
		when ('g') { return 7; }
		when ('h') { return 8; }
		when ('i') { return 9; }
		when ('l') { return 10; }
		when ('k') { return 11; }
		when ('m') { return 12; }
		when ('f') { return 13; }
		when ('p') { return 14; }
		when ('s') { return 15; }
		when ('t') { return 16; }
		when ('w') { return 17; }
		when ('y') { return 18; }
		when ('v') { return 19; }
		dedault { return -1; }
	}
}

