#!/usr/bin/perl -w
use Getopt::Std;  # to parse command line parameters
use strict;
use warnings;

sub usage(){
  print  "perl RandomSplit.pl -k maxNumberOfSeqs -i alignmentFileName -z subAlignmentFolder\n";
  exit;
}

my %options=();
my $opt_string = 'k:i:z:h';
getopts("$opt_string",\%options) or usage();

if (!keys %options) { usage(); };
usage() if $options{h};

my $maxNSeqs = $options{k};
my $input_file = $options{i};
my $output_folder = $options{z};

if ($maxNSeqs < 8) {
	print "maxNumberOfSeqs  must be greater than 7";
	exit;
}

system("mkdir $output_folder");

my $line;
my $inFile;
my $outFile;
 
my $lk_file;
my $stats_file;
my $tree_file;
my $aln_file;

if (1) {
	my %sequencesHash = ( );
	open ( my $inFile, '<',  $input_file)	or die "Cannot open the input file: $input_file!";
	my $seqId = "";
	my $seqData = "";
	$line = <$inFile>;
	my @values = split(" ", $line);
	my $tax = $values[0];
	my $site = $values[1];

	for (1..$tax) {
		$line = <$inFile>;
		@values = split(" ", $line);
		$seqId = $values[0];
		$seqData = $values[1];
		if ( !exists $sequencesHash{$seqData} ){
			$sequencesHash{$seqData} = $seqId;
		}
	}
	my $totalSeqs = keys( %sequencesHash );
	print "Total sequences: $totalSeqs\n";

	my $fileId = 1;
	my $minNSeqs = $maxNSeqs/2;
	while ($totalSeqs>$maxNSeqs) {
		my $formatedFileId = sprintf("%03d", $fileId);;
		my $randNumOfSeqs = int(rand($minNSeqs)) + $minNSeqs;
		print "randNumOfSeqs: $randNumOfSeqs\n";
		open ( my $outFile, '>', $output_folder."/".$input_file."_cluster_".$formatedFileId )		   or die "Cannot open the output file $!";
		printf $outFile $randNumOfSeqs."\t".$site."\n";
		for (1..$randNumOfSeqs) {
			my $randSequencesId = int(rand($totalSeqs))+1;
			my $key, my $value;
			for (1..$randSequencesId) {
				($key, $value) = each(%sequencesHash);
			}
			printf $outFile $value."\t".$key."\n";
			delete($sequencesHash{$key});
			$totalSeqs = keys( %sequencesHash );
		}
		close ($outFile);
		$fileId++;
	}

	$totalSeqs = keys( %sequencesHash );
	print "randNumOfSeqs: $totalSeqs\n";
	my $formatedFileId = sprintf("%03d", $fileId);;
	open ( my $outFile, '>', $output_folder."/".$input_file."_cluster_".$formatedFileId )		   or die "Cannot open the output file $!";
	printf $outFile $totalSeqs."\t".$site."\n";
	while( my ($k, $v) = each(%sequencesHash)) {		printf $outFile $v."\t".$k."\n";    }
	close ($outFile);

	close ($inFile);
}